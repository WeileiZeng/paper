#g="1 0 1 1 1 0 0 "
#./qhpc qhpc=0 n1=28 g1="[1 1 0 1]" r1=25 r2=3 g2="[$g $g $g $g]" fout=trx

# echo creating sample codes  
# for (( cw=2; cw<=3; cw++)) ; do
#     for (( rw=cw+1; rw<=5; rw++)) ; do 	
# 	for (( n=2*rw ; n<=24; n=n+rw )) ; do 
# 	    ./gallager n=$n cw=$cw rw=$rw ntry=10000 seed=-1 dmin=100 fout=n${n}_${cw}_${rw} > code_n$n.out 
# 	    grep saving code_n$n.out 
# #    ./qhpc fin1=n${n} fout=n$n debug=1 > qhpc_n$n.out 
# #    grep "rank mG" qhpc_n$n.out 
# 	done 
#     done
# done
# exit 

for (( n=8 ; n<=16; n+=4 )) ; do
    cw=3; rw=4;
#    ./gallager n=$n cw=$cw rw=$rw ntry=10000 seed=-1 dmin=100 fout=n${n} > code_n$n.out 
    grep saving code_n$n.out 
    grep saving code_n$n.out >> qbp_log_sh.out 
#    ./qhpc fin1=n${n} fout=n$n debug=1 > qhpc_n$n.out 
    grep "rank mG" qhpc_n$n.out 
    grep "rank mG" qhpc_n$n.out >> qbp_log_sh.out 
    echo "# scanning n$n" >> qbp_log_sh.out 
    echo "# scanning n$n" 
    for (( ff=0 ; ff<=8; ff+=4 )) ; do 
	num=`printf "%2.0d" $ff`
#	echo 0.$num n$n
	fout=ffn_${ff}_n${n}.tmp 
	./qbp fin=n$n fmax=$ff pvals="0.01:0.01:0.05" lmax=64 seed=-1 > $fout
	grep "# ans" $fout | sed -e "s/# ans//" >> qbp_log_sh.out 
	grep "# ans" $fout | sed -e "s/# ans//" 
    done 
done
