/* 	$Id: gallager.C,v 1.2 2015/05/27 21:23:45 leonid Exp $	 */

#ifndef lint
static char vcid[] = "$Id: gallager.C,v 1.2 2015/05/27 21:23:45 leonid Exp $";
#endif /* lint */
// Generate some example LDPC codes
#include <itpp/itcomm.h>
#include <stdio.h>
#include "templ.H"
using namespace itpp;
using namespace std;

int debug=1;

int do_gen_matr(GF2mat & H, /* input: orig parity check; output: permutted cols  */
		GF2mat & G, ivec & perm){  /* return: standard form G, permutation */
  /* input: H and G matrices.  Permute columns, render G into
     upper triangle.  Return  rank of G. */ 
  int r, n=H.cols(); //int r0=H.rows();
  GF2mat T, U;
  r = H.T_fact(T, U, perm);
  H.permute_cols(perm,false); /* they are now in the same order as for U */
//  cout << "rank="<< r<< " orig="<<r0<<" x "<< n<< endl;
  U.set_size(r,n,true); 
  GF2mat M=U.get_submatrix(0,0,r-1,r-1);
  G=M.inverse()*U; /* now U=(I,A) */
  //  cout << U<< endl;
  G=G.get_submatrix(0,r,r-1,n-1).transpose(); 
  G=G.concatenate_horizontal(eye_b(n-r));
  //cout << G*GG.transpose()<< endl; 
  //  H=GG.sparsify();  
  return r;
}

int do_dist_rand(const GF2mat & G0, const GF2mat & H0, int tries, 
		 int dmin, int kmax){
  /* random window algorithm from given generator matrix. 
   * If smaller than dmin, or if equal to dmin and kmax is not
   * smaller, we are not interested either
   */
  int r, n=G0.cols();   
  int wmin=n;
  GF2mat G=G0, H=H0; 
  //  cout << G*H.transpose()<< endl;
  for(int l=0;l<tries;l++){ 
    ivec perm,ind = sort_index(randu(n)); // random permutation 
    G.permute_cols(ind,false); 
    H.permute_cols(ind,false); 
    GF2mat T, U;
    r = G.T_fact(T, U, perm);  /* gauss elimination trying for these cols */
    H.permute_cols(perm,false); 
    U.set_size(r,n,true); 
    GF2mat M=U.get_submatrix(0,0,r-1,r-1);
    G=M.inverse()*U; /* now U=(I,A) systematic form of G */
    //    cout << "l="<<l<<" "<< G*H.transpose()<< endl;
    //    cout << "l="<<l<<" "<< G<<endl;
    for(int i=0;i<r;i++){
      int w=weight(G.get_row(i));
      if (w<wmin)
	wmin=w; /* weight-one encoded vectors */
    }
    if((wmin<dmin)||((wmin==dmin)&&(n-r<=kmax))){
      wmin=-wmin; /* this is not interesting -- terminate early */
      break;
    }
  }
  return wmin;
}

int do_dist(const GF2mat & G){ 
  int k=G.rows(), n=G.cols();
  bvec v(n); 
  int w1,w=n;
  for (long b=1;b<(1<<k);b++){
    v.zeros();
    for (int i=0;i<k;i++)
      if(BIT(b,i))
	v+=G.get_row(i);    
    if((w1=weight(v))<w){
      w=w1;
//      cout<< b<< " "<< v<< endl;
    }
  }   
  return w;
}


int do_weights_dist(const GF2mat & G, ivec & wei){ 
  int k=G.rows(), n=G.cols();
  wei.set_size(1+n); wei.zeros(); wei(0)=1;
  bvec v(n); 
  int w;
  for (long b=1;b<(1<<k);b++){
    v.zeros();
    for (int i=0;i<k;i++)
      if(BIT(b,i))
	v+=G.get_row(i);   
    w=weight(v);
    wei(w)++;
//    cout << b<< " "<< w<< " "<< v<< endl;
  }   
  if(debug&32)
    cout << "weights="<< wei<< endl;
  wei(0)=0;
  for(w=0;w<n;w++)
    if(wei(w))
      break;  
//  cout << " sum="<< sum(wei)<< endl;
  return w;
}

int main(int argc, char **argv){
  Parser p; 
  Real_Timer timer;

  p.init(argc,argv);
  p.set_silentmode(false); /* shut down echo */
  if((argc==1)||(strcmp(argv[1],"--help")==0)||(strcmp(argv[1],"-h")==0)){
    cout<< argv[0]<< ": generate random Gallager (rw,cw)-regular code\n"
        << "\tversion: " << vcid << "\n"
	<< "\tusage: "<< argv[0]<< " param=val\n"
        << "\tdebug=1: bitmap for aux information\n"
	<< "\tstring: fout=\"try\": base name for saving\n"
	<< "\teither n or rep should be specified, n=rep*rw, not both\n"
	<< "\tdefault: n=28 cw=3 rw=4 ntry=1 dmin=3 kmin=1 seed=0\n"
	<< endl;
    exit (-1);
  }
  /* int debug=1; */ p.get(debug,"debug"); 
  if(debug==0) p.set_silentmode(true); /* shut down echo */
  int n=-28, cw=3, rw=4, rep=-7; /* default dim, col and row weights */
  p.get(n,"n");  p.get(cw,"cw");  p.get(rw,"rw");
  if(n<0){ /* n was not specified */
    p.get(rep,"rep"); if(rep<0){
      n=abs(n); rep=abs(rep);
    }
    else
      n=rw*rep;
  }
  rep=n/rw;
  n=rw*rep;
  
  int ntry=1, dmin=3;  p.get(ntry,"ntry");  p.get(dmin,"dmin");
  int kmin=1; p.get(kmin,"kmin");
  int seed=0; p.get(seed,"seed");
  if(seed==-1)
    RNG_randomize();
  else
    RNG_reset(seed);

  string fout="try";   p.get(fout,"fout");
  
  if(debug)
    cout << "# generating Gallager ("<< cw<<","<<rw<<") code n="<< n
	 << " rep="<< rep<< " k>="<< n-cw*rep<< endl;
  bmat row(1,rw); row.ones(); /* row of ones */
  Sparse_Mat<bin> blk=kronecker(eye_b(rep),row);  

  GF2mat H0; int w0=0, k0=0; /* saved params */
  if(debug)
    timer.tic(); 

  for(int j=0;j<ntry;j++){
    GF2mat ans(blk.full());

    for(int i=1;i<cw;i++){
      ivec ind = sort_index(randu(n)); // random permutation 
      GF2mat blk1(blk);
      blk1.permute_cols(ind,false); 
      ans=ans.concatenate_vertical(blk1);
    }
  
    ivec perm;
    GF2mat P=ans,G;
    int r=do_gen_matr(P,G,perm), k=n-r;
    if(k>=kmin){
    //    cout << G<< endl;
#if 0
      ivec wei,wei0; 
      int w=do_weights_dist(G,wei);
      wei0=wei;
      wei.set_size(rw+1,true);
      if((sum(wei)<k)||(debug&4))
	cout << wei0<< "  ["<<n<<","<< k<<","<<w<<"]"
	     <<" [["<<n<<","<< k-sum(wei)<<","<<w<<"]]" << endl;
#else 
      //    int w=do_dist(G);
#endif 
      int w=do_dist_rand(G,P,ntry,w0,k0);
      //    cout << "w="<< w<< " w1="<< w1<< endl;
      if(debug&4)
	cout << "j="<<j<<" of "<<ntry
	     <<" ["<<n<<","<< k<<","<<w<<"] so far best [" 
	     <<n<<","<< k0 <<","<<w0<<"]"
	     <<endl;
      if((w>w0)||((w==w0)&&(k>k0))){
	if(debug){
	  double elapsed=timer.get_time();
	  cout << "j="<<j<<" of "<<ntry
	       <<" ["<<n<<","<< k<<","<<w<<"] so far best [" 
	       <<n<<","<< k0 <<","<<w0<<"]"
	       << " elapsed time = "<<  elapsed << " sec "
	       <<endl;
	}
	H0=P; k0=k; w0=w;
      }
      if(w>=dmin)
	break;
    }
  }
  if(debug)
    timer.toc_print();
  cout << "saving code ["<<n<<","<< k0 <<","<<w0<<"]"
       <<" cw="<< cw<< " rw="<< rw<< endl;
  if(debug&8)
    cout << H0<< endl;
  GF2mat_sparse_alist alist;
  alist.from_sparse(H0.sparsify()); 
  alist.write(fout+".dat");
  //  cout<< G*P.transpose()<< endl;  
  return 0;
}
