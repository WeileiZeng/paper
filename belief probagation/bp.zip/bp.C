#include <itpp/itcomm.h>
#include <sstream>
using namespace std;
using namespace itpp;
int main(int argc, char **argv){
  if (argc < 2) {
    it_info("Usage: " << argv[0] << " codec_file.it [EbN0_dB]");
    return 1;
  }
  int64_t Nbits = 5000000000LL; // maximum number of bits simulated
  // for each SNR point
  int Nbers = 1000; // target number of bit errors per SNR point
  double BERmin = 1e-5; // BER at which to terminate simulation
  vec pvals = "0.5:0.1:1.5"; // from 1 to 2 inclusive at increment of 0.2
  //  LDPC_Generator_Systematic G; // for codes created with ldpc_gen_codes since generator exists
  LDPC_Code C(argv[1]);
  //  bool single_snr_mode = false;
  cout << "# Running with p: " << pvals << endl;
  // High performance: 2500 iterations, high resolution LLR algebra
  C.set_exit_conditions(50);
  // Alternate high speed settings: 50 iterations, logmax approximation
  // C.set_llrcalc(LLR_calc_unit(12,0,7));
  //  cout << C << endl;
  int N = C.get_nvar(); // number of bits per codeword
  bvec bitsin = zeros_b(N);
  RNG_randomize();
  for (int j = 0; j < length(pvals); j++) {
    double pp=pow(10.0,-pvals(j));
    cout<< "running p="<< pp<< endl;
    BERC berc; // Counters for coded and uncoded BER
    BLERC ferc; // Counter for coded FER
    ferc.set_blocksize(C.get_nvar() - C.get_ncheck());    
    BSC bsc(pp); // initialize BSC
    for (int64_t i = 0; i < Nbits; i += C.get_nvar()) {
    bvec rec_bits = bsc(bitsin);    
    vec s(N);
    for(int i=0;i<N;i++)
      s(i)=(rec_bits(i)==1)?-log(1.0/pp-1.0):log(1.0/pp-1.0);	
    QLLRvec llr;
    int ans=C.bp_decode(C.get_llrcalc().to_qllr(s), llr);
    bvec bitsout = llr < 0;
    if(0 && (ans<0)){
      if(ans<0) cout << "# fail to converge "<< ans<< endl;
      else cout << "# converged! "<< ans<< endl;
      cout<<"# rec_bits=\n# "<< rec_bits<< endl;
      cout << "# bitsout=\n# "<< bitsout << endl;
      cout << "# llr=\n# "<< llr << endl;
      cout << "# err=\n# "<< rec_bits+bitsout << endl;
    }
      // bvec bitsout = C.decode(softbits); // (only systematic bits)
      // Count the number of errors
    berc.count(bitsin, bitsout);
    ferc.count(bitsin, bitsout);
    if (berc.get_errors() > Nbers)
      break;
    }       
    cout << "# p = " << pp << " Simulated "
	 << ferc.get_total_blocks() << " frames and "
	 << berc.get_total_bits() << " bits. "
	 << "Obtained " << berc.get_errors() << " bit errors. "
	 << " BER: " << berc.get_errorrate()
	 << " FER: " << ferc.get_errorrate() << endl << flush;    
    cout << "## ans " << pp << " " << N 
	 << " " << berc.get_errorrate()
	 << " " << ferc.get_errorrate() << endl << flush;
    
    if (berc.get_errorrate() < BERmin)
      break;
  }
  cout << endl<< endl;
  return 0;
}
