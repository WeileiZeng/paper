#ifndef UTIL_H
#define UTIL_H

#define ERROR(fmt,...)                                                 \
  do{                                                                  \
    printf("#:[31;1m *** ERROR: " fmt " ***[0m \n",##__VA_ARGS__); \
    exit(-1);                                                          \
  }                                                                    \
  while(0)

#endif /* UTIL_H */
