/* Exersize eigen with mybool values */

#include "eig_gf2.H"
#include <stdio.h>
#include <iostream>
#include <sys/time.h>
//#include <rng.h>
#include "util.h"
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <unsupported/Eigen/KroneckerProduct>
#include <stdlib.h>
//#include <vector>
using namespace Eigen;
using namespace std;

typedef SparseMatrix<mybool> SpMatB; // column-major sparse matrix
typedef Matrix<mybool, Dynamic, Dynamic> MatXB;
typedef SparseVector<mybool> SpVecB;
typedef Vector<mybool, Dynamic> VecXB;

typedef SparseMatrix<double> SpMatD;
typedef SparseVector<double> SpVecD;
typedef Vector<double, Dynamic> VecXD;
typedef SparseVector<double> SpVecD;

typedef SparseMatrix<int> SpMatI;
typedef SparseVector<int> SpVecI;
typedef Vector<int> VecXI;
typedef SparseVector<int> SpVecI;


